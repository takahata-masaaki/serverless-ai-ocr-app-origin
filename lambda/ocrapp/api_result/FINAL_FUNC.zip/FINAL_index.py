import os, json, boto3
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal): return float(obj)
        return super(DecimalEncoder, self).default(obj)

def handler(event, context):
    # 💡 削除を成功させるための必須設定（CORS）
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token"
    }

    # ブラウザからの事前確認(OPTIONS)には即座にOKを返す
    if event.get('httpMethod') == 'OPTIONS':
        return {"statusCode": 200, "headers": headers, "body": ""}

    ddb = boto3.resource('dynamodb')
    images_t = ddb.Table('OcrStarterStack-DatabaseImagesTable50A0FC36-DUJU7RD1D23Z')
    jobs_t = ddb.Table('OcrAppStack-DatabaseJobsTable7C20F61C-25WQGT70DRID')
    
    path_params = event.get('pathParameters') or {}
    image_id = path_params.get('image_id') or path_params.get('proxy', '').split('/')[-1]
    app_name = (event.get('queryStringParameters') or {}).get('app_name', 'OCR_WORKER_Test02')

    try:
        # ---------------------------------------------------------
        # [DELETE] 確実な削除ロジック
        # ---------------------------------------------------------
        if event.get('httpMethod') == 'DELETE':
            # 1. 絶対にDynamoDBのデータを消す
            images_t.delete_item(Key={'app_name': app_name, 'image_id': image_id})
            jobs_t.delete_item(Key={'id': image_id})
            
            # 2. S3の削除（権限エラー等で止まらないようにtry-exceptで囲む）
            try:
                s3 = boto3.client('s3')
                bucket = 'ocrappstack-apidocumentbucket1e0f08d4-olnl5bocx2v3'
                for prefix in [f"documents/{image_id}", f"outputs/{image_id}"]:
                    res = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
                    if 'Contents' in res:
                        s3.delete_objects(Bucket=bucket, Delete={'Objects': [{'Key': o['Key']} for o in res['Contents']]})
            except Exception as e:
                print(f"S3 Delete Ignored: {str(e)}") # S3エラーは無視して削除完了とする
                
            return {"statusCode": 200, "body": json.dumps({"status": "deleted"}), "headers": headers}

        # ---------------------------------------------------------
        # [GET] データ取得とコストの動的計算
        # ---------------------------------------------------------
        img = images_t.get_item(Key={'app_name': app_name, 'image_id': image_id}).get('Item', {})
        job = jobs_t.get_item(Key={'id': image_id}).get('Item', {})
        
        data = {**job, **img}
        
        in_t = int(job.get('input_tokens', 0))
        out_t = int(job.get('output_tokens', 0))
        p_count = int(job.get('page_count', 1))
        
        # 💡 DBの値が0円なら、ここでトークン数から強制的に正しいコストを計算する
        calculated_cost = (in_t * 0.00045) + (out_t * 0.0022) + (p_count * 0.225)
        
        fn = img.get('filename', 'unknown.pdf')
        # 画面表示用のハックを生成（計算した実数コストを使用）
        data['filename'] = f"{fn} ［約{calculated_cost:.3f}円 / {in_t}in, {out_t}out］"

        return {"statusCode": 200, "body": json.dumps(data, cls=DecimalEncoder), "headers": headers}
        
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)}), "headers": headers}
