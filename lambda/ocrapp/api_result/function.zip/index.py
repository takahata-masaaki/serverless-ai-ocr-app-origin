import os, json, boto3
from datetime import datetime, timezone
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def handler(event, context):
    ddb = boto3.resource('dynamodb')
    s3 = boto3.client('s3')
    
    # 💡 捏造を排し、Lambdaが現在持っている「本物の環境変数」をそのまま使用
    # IMAGES_TABLE_NAME は OcrStarterStack 側の本物のテーブルを指しています
    images_t = ddb.Table(os.environ['IMAGES_TABLE_NAME'])
    jobs_t = ddb.Table(os.environ['JOBS_TABLE_NAME'])
    usage_t = ddb.Table(os.environ.get('USAGE_METRICS_TABLE_NAME', 'UsageMetricsTable'))
    bucket_name = os.environ.get('BUCKET_NAME')
    
    http_method = event.get('httpMethod', 'GET')
    path_params = event.get('pathParameters') or {}
    image_id = path_params.get('image_id') or path_params.get('proxy', '').split('/')[-1] or event.get('path', '').split('/')[-1]
    query_params = event.get('queryStringParameters') or {}
    app_name = query_params.get('app_name', 'OCR_WORKER_Test')
    
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, DELETE, OPTIONS",
        "Content-Type": "application/json"
    }

    try:
        # ------------------------------------------
        # [DELETE] 削除処理の完全実装
        # ------------------------------------------
        if http_method == 'DELETE':
            # 1. DynamoDBからの実データ削除
            images_t.delete_item(Key={'app_name': app_name, 'image_id': image_id})
            jobs_t.delete_item(Key={'id': image_id})
            
            # 2. S3からの物理ファイル削除 (documents/ と outputs/)
            if bucket_name:
                for prefix in [f"documents/{image_id}", f"outputs/{image_id}"]:
                    res = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
                    if 'Contents' in res:
                        objects_to_delete = [{'Key': obj['Key']} for obj in res['Contents']]
                        s3.delete_objects(Bucket=bucket_name, Delete={'Objects': objects_to_delete})
            
            return {"statusCode": 200, "body": json.dumps({"status": "deleted"}), "headers": headers}

        # ------------------------------------------
        # [GET] 実体データの取得と返却
        # ------------------------------------------
        # 捏造を排除するため、DBの戻り値 Item をそのまま使用
        img_item = images_t.get_item(Key={'app_name': app_name, 'image_id': image_id}).get('Item', {})
        job_item = jobs_t.get_item(Key={'id': image_id}).get('Item', {})
        
        if not img_item and not job_item:
            return {"statusCode": 404, "body": json.dumps({"error": "No Data in DB"}), "headers": headers}
        
        # すべてのデータをマージ (extract_text等が含まれる)
        response_data = {**job_item, **img_item}
        
        # コスト実数値の取得
        cost = img_item.get('cost_estimate_jpy', 0)
        in_t = job_item.get('input_tokens', 0)
        out_t = job_item.get('output_tokens', 0)
        current_month = datetime.now(timezone.utc).strftime('%Y-%m')
        monthly_cost = usage_t.get_item(Key={"metric_date": current_month}).get("Item", {}).get("total_cost_jpy", 0)
        
        # フロントエンドが split できる形式を作成
        base_fn = img_item.get('filename', 'unknown.pdf')
        response_data['filename'] = f"{base_fn} ［約{float(cost)}円 / {int(in_t)}in, {int(out_t)}out |Month:{float(monthly_cost)}］"
        response_data['id'] = image_id

        return {"statusCode": 200, "body": json.dumps(response_data, cls=DecimalEncoder), "headers": headers}

    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)}), "headers": headers}
