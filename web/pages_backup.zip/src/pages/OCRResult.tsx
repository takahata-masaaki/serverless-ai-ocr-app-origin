import { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api, { runAgent as apiRunAgent } from "../utils/api";
import { OcrWord, OcrBoundingBox, OcrResponse } from "../types/ocr";
import { ExtractionMapping } from "../types/extraction";
import { Field } from "../types/app-schema";
import { Suggestion, Tool } from "../types/agent";
import { isOcrEnabled } from "../config";
import ImagePreview from "../components/ImagePreview";
import OcrResultEditor from "../components/OcrResultEditor";
import ExtractionStatusDisplay from "../components/ExtractionStatusDisplay";
import ExtractedInfoDisplay from "../components/ExtractedInfoDisplay";
import Toast from "../components/Toast";
import ConfirmModal from "../components/ConfirmModal";
import CustomPromptModal from "../components/CustomPromptModal";

const RESULT_API_BASE = "https://aj45ozgo95.execute-api.us-east-1.amazonaws.com/prod";

const styles = {
  container: "p-4 w-full h-screen overflow-y-auto lg:overflow-hidden",
  row: "flex flex-col lg:flex-row w-full lg:h-[calc(100vh-2rem)] gap-4",
  panel: "w-full flex flex-col",
  leftPanel: "lg:w-1/2 p-4 overflow-hidden flex flex-col min-h-[50vh] lg:min-h-0",
  rightPanel: "lg:w-1/2 p-4 flex flex-col min-h-[50vh] lg:min-h-0",
  header: "flex justify-between mb-4 flex-shrink-0 min-h-[60px] items-center flex-wrap gap-2",
  title: "text-xl font-semibold",
  loadingContainer: "flex justify-center items-center flex-grow",
  spinner:
    "animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500",
  scrollContainer: "flex-grow overflow-y-auto min-h-0",
  contentArea: "flex-grow overflow-hidden flex flex-col min-h-0",
  scrollContainerStyle: { maxHeight: "calc(100vh - 200px)" },
};

function OcrResult() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // OCR結果の状態
  const [loading, setLoading] = useState(true);
  const [imageSrc, setImageSrc] = useState("");
  const [imageUrls, setImageUrls] = useState<Array<{page: number, url: string}>>([]);
  const [_markdownText, setMarkdownText] = useState<string>("");
  const [currentPageIndex, setCurrentPageIndex] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [isMultipage, setIsMultipage] = useState(false);
  const [ocrWords, setOcrWords] = useState<OcrWord[]>([]);
  const [boundingBoxes, setBoundingBoxes] = useState<OcrBoundingBox[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [filename, setFilename] = useState<string>("");

  // 抽出結果の状態
  const [extractionStatus, setExtractionStatus] = useState<string>("pending");
  const [extractedInfo, setExtractedInfo] = useState<Record<string, any>>({});
  const [appFields, setAppFields] = useState<Field[]>([]);
  const [appName, setAppName] = useState<string>("");
  const [mapping, setMapping] = useState<ExtractionMapping>({});
  const [pollingAttemptCount, setPollingAttemptCount] = useState(0);
  const [activeView, setActiveView] = useState<"ocr" | "extraction">(
    "extraction" // OCRモードに関係なく、常に抽出画面から開始
  );
  const [verificationCompleted, setVerificationCompleted] = useState(false);

  // ポーリング設定
  const POLLING_INTERVAL = 3000; // 3秒
  const MAX_POLLING_ATTEMPTS = 20; // 最大60秒（3秒 x 20回）
  
  // 状態変数を追加
  const [toast, setToast] = useState<{
    show: boolean;
    message: string;
    type: 'success' | 'error' | 'info';
  }>({
    show: false,
    message: '',
    type: 'success'
  });
  const [agentStatus, setAgentStatus] = useState<'idle' | 'running' | 'completed'>('idle');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [customPromptModalOpen, setCustomPromptModalOpen] = useState(false);
  let statusCheckTimer: NodeJS.Timeout | null = null;

  // 現在のページのバウンディングボックスを生成
  const updateBoundingBoxesForCurrentPage = useCallback((pageIndex?: number) => {
    const targetPageIndex = pageIndex !== undefined ? pageIndex : currentPageIndex;
    const currentPage = targetPageIndex + 1;
    
    let currentPageWords;
    if (!isMultipage) {
      currentPageWords = ocrWords;
    } else {
      currentPageWords = ocrWords.filter(word => word.page === currentPage);
    }
    
    const boxes: OcrBoundingBox[] = currentPageWords.map((word, index) => {
      if (!word.points || word.points.length < 4) {
        return {
          id: index,
          top: 0,
          left: 0,
          width: 0,
          height: 0,
          text: word.content || "",
        };
      }

      const points = word.points;
      const minX = Math.min(...points.map((p) => p[0]));
      const minY = Math.min(...points.map((p) => p[1]));
      const maxX = Math.max(...points.map((p) => p[0]));
      const maxY = Math.max(...points.map((p) => p[1]));

      return {
        id: index,
        top: minY,
        left: minX,
        width: maxX - minX,
        height: maxY - minY,
        text: word.content || "",
      };
    });

    setBoundingBoxes(boxes);
  }, [ocrWords, currentPageIndex, isMultipage]);

  // ページ切り替え機能
  const goToPreviousPage = () => {
    if (currentPageIndex > 0) {
      const newIndex = currentPageIndex - 1;
      setCurrentPageIndex(newIndex);
      setImageSrc(imageUrls[newIndex]?.url || "");
      
      // バウンディングボックスを現在のページ用に更新
      updateBoundingBoxesForCurrentPage(newIndex);
      // 選択状態をリセット
      setSelectedIndex(null);
    }
  };

  const goToNextPage = () => {
    if (currentPageIndex < totalPages - 1) {
      const newIndex = currentPageIndex + 1;
      setCurrentPageIndex(newIndex);
      setImageSrc(imageUrls[newIndex]?.url || "");
      
      // バウンディングボックスを現在のページ用に更新
      updateBoundingBoxesForCurrentPage(newIndex);
      // 選択状態をリセット
      setSelectedIndex(null);
    }
  };

  // 表示切替
  const changeView = (view: "ocr" | "extraction") => {
    // 画面切り替え時に初期スクロールフラグをリセット
    setActiveView(view);
  };

  // ネストされたオブジェクトパスから値を取得するヘルパー関数
  const getNestedValue = (obj: any, path: string): any => {
    return path.split('.').reduce((current, key) => {
      return current && current[key] !== undefined ? current[key] : undefined;
    }, obj);
  };

  // 抽出項目クリック時のハイライト機能
  const handleExtractedFieldClick = useCallback((fieldPath: string) => {
    const wordIndices = getNestedValue(mapping, fieldPath) || [];
    if (wordIndices.length === 0) {
      return;
    }

    // 最初の単語のページを取得
    const firstWordIndex = wordIndices[0];
    const targetWord = ocrWords[firstWordIndex];
    
    if (!targetWord) {
      return;
    }
    
    const targetPage = targetWord.page || 1;
    const targetPageIndex = targetPage - 1;

    // 現在のページと異なる場合はページ切り替え
    if (targetPageIndex !== currentPageIndex) {
      setCurrentPageIndex(targetPageIndex);
      setImageSrc(imageUrls[targetPageIndex]?.url || "");
      
      // ページ切り替え後にハイライト処理を実行
      setTimeout(() => {
        highlightWordsOnCurrentPage(fieldPath, targetPage);
      }, 100); // 画像読み込み待ち
    } else {
      // 同じページの場合は即座にハイライト
      highlightWordsOnCurrentPage(fieldPath, targetPage);
    }
  }, [mapping, ocrWords, currentPageIndex, imageUrls]);

  const highlightWordsOnCurrentPage = useCallback((fieldPath: string, targetPage: number) => {
    const wordIndices = getNestedValue(mapping, fieldPath) || [];
    
    // 対象ページの単語のみをフィルタ
    const currentPageWordIndices = wordIndices.filter((index: number) => {
      const word = ocrWords[index];
      return word && (word.page === targetPage || (!word.page && targetPage === 1));
    });
    
    if (currentPageWordIndices.length === 0) {
      return;
    }
    
    // 現在のページでの相対インデックスに変換
    const currentPageWords = isMultipage 
      ? ocrWords.filter(word => (word.page === targetPage || (!word.page && targetPage === 1)))
      : ocrWords;
      
    const relativeIndices = currentPageWordIndices.map((globalIndex: number) => {
      const word = ocrWords[globalIndex];
      return currentPageWords.findIndex(pageWord => 
        pageWord.content === word.content && 
        JSON.stringify(pageWord.points) === JSON.stringify(word.points)
      );
    }).filter((index: number) => index !== -1);
    
    // 複数の単語をハイライト（最初の単語を選択状態に）
    if (relativeIndices.length > 0) {
      setSelectedIndex(relativeIndices[0]);
    }
  }, [mapping, ocrWords, isMultipage, boundingBoxes]);

  // OCR結果またはページが変更された時にバウンディングボックスを更新
  useEffect(() => {
    if (ocrWords.length > 0) {
      console.log("バウンディングボックスを更新中...", {
        wordsCount: ocrWords.length,
        currentPage: currentPageIndex + 1,
        isMultipage
      });
      updateBoundingBoxesForCurrentPage();
    }
  }, [ocrWords, currentPageIndex, isMultipage, updateBoundingBoxesForCurrentPage]);

  // OCR結果の取得
  const fetchOcrResult = useCallback(async () => {
    if (!id) return;

    try {
      setLoading(true);

      // OCR結果を取得
      const currentAppName =
        new URLSearchParams(window.location.search).get('app_name') ||
        appName ||
        'aClass_quiz_v01';

      const response = {
        data: await fetch(
          `${RESULT_API_BASE}/ocr/result/${id}?app_name=${encodeURIComponent(currentAppName)}`
        ).then(r => r.json())
      } as { data: OcrResponse };
      const payload =
        typeof (response.data as any)?.body === "string"
          ? JSON.parse((response.data as any).body)
          : ((response.data as any)?.body ?? response.data);

      const { filename, app_name, json_url, markdown_url, source_file_url } = payload as any;
      setImageSrc(source_file_url);
      
      // ファイル名を設定
      setFilename(filename || "");
      
      // app_nameを設定
      if (app_name) {
        setAppName(app_name);
      }

      }

      setMarkdownText("");
      if (markdown_url) {
        try {
          const md = await fetch(markdown_url).then(r => r.text());
          setMarkdownText(md || "");
        } catch (e) {
          console.error("markdown_url の取得に失敗しました:", e);
          setMarkdownText("");
        }
      }

      let ocrResult: any = null;
      if (json_url) {
        try {
          ocrResult = await fetch(json_url).then(r => r.json());
          console.log("structured.json を取得しました:", ocrResult);
        } catch (e) {
          console.error("structured.json の取得に失敗しました:", e);
        }
      }

        // 署名付きURLで画像を取得
        try {
          console.log("署名付きURLで画像を取得しています...");
          const urlResponse = await api.get(`/ocr/download-url/${id}`, {
            params: { app_name: currentAppName }
          });
          console.log("取得した署名付きURL:", urlResponse.data);

          if (urlResponse.data.is_multipage && urlResponse.data.presigned_urls) {
            // 複数画像の場合
            setIsMultipage(true);
            setTotalPages(urlResponse.data.total_pages);
            setImageUrls(urlResponse.data.presigned_urls.map((item: any) => ({
              page: item.page,
              url: item.presigned_url
            })));
            setImageSrc(urlResponse.data.presigned_urls[0]?.presigned_url || "");
            setCurrentPageIndex(0);
            console.log(`複数画像を取得しました: ${urlResponse.data.total_pages}ページ`);
          } else {
            // 単一画像の場合
            setIsMultipage(false);
            setTotalPages(1);
            setImageUrls([{ page: 1, url: urlResponse.data.presigned_url }]);
            setImageSrc(urlResponse.data.presigned_url);
            setCurrentPageIndex(0);
            console.log("単一画像を取得しました");
          }
        } catch (error) {
          console.error("署名付きURL取得エラー:", error);
          // フォールバック: 元ファイルURLを表示（PDFなら iframe 側で表示される）
          setImageSrc(source_file_url || "");
          setIsMultipage(false);
          setTotalPages(1);
          setImageUrls(source_file_url ? [{ page: 1, url: source_file_url }] : []);
        }

        // OCR結果を設定（OCRが有効な場合のみ）
        if (isOcrEnabled()) {
          if (ocrResult && ocrResult.words && Array.isArray(ocrResult.words)) {
            setOcrWords(ocrResult.words);
            console.log("OCR結果を設定しました:", ocrResult.words.length, "個の単語");

            if (ocrResult.words.some((word: any) => word.page)) {
              const pageInfo = ocrResult.words.reduce((acc: Record<number, number>, word: any) => {
                const page = word.page || 1;
                acc[page] = (acc[page] || 0) + 1;
                return acc;
              }, {} as Record<number, number>);
              console.log("ページ別単語数:", pageInfo);
            }
          } else {
            console.warn("OCRが有効ですが、OCR結果が見つかりません");
            setOcrWords([]);
            setBoundingBoxes([]);
          }
        } else {
          console.log("OCRモードが無効のため、OCR結果の処理をスキップします");
          setOcrWords([]);
          setBoundingBoxes([]);
        }

      // 抽出情報を取得
      await fetchExtractionInfo();

      setLoading(false);
    } catch (error) {
      console.error("OCR結果の取得に失敗しました:", error);
      setLoading(false);
    }
  }, [id]);

  // 抽出情報の取得
  const fetchExtractionInfo = async () => {
    if (!id) return;

    try {
      console.log("抽出情報を取得中...");
      const currentAppName =
        new URLSearchParams(window.location.search).get('app_name') ||
        appName ||
        'aClass_quiz_v01';

      const response = {
        data: await fetch(
          `${RESULT_API_BASE}/ocr/result/${id}?app_name=${encodeURIComponent(currentAppName)}`
        ).then(r => r.json())
      } as { data: any };

      console.log("抽出情報のレスポンス:", response.data);

      setExtractionStatus(response.data.status || "pending");

      if (response.data.app_name) {
        setAppName(response.data.app_name);
      }

      setVerificationCompleted(!!response.data.verification_completed);

      if (response.data.status === "completed") {
        console.log("抽出情報の取得完了 - ステータス: completed");
        
        // ポーリングを停止
        if (statusCheckTimer) {
          clearInterval(statusCheckTimer);
          statusCheckTimer = null;
        }

        // 抽出フィールド情報を更新
        if (response.data.fields) {
          setAppFields(response.data.fields);
        }

        // 抽出情報が空でも明示的に設定
        setExtractedInfo(response.data.extracted_info || {});
        if (response.data.mapping) {
          setMapping(response.data.mapping);
        } else {
          // マッピング情報がない場合はシンプルな推測を試みる
          generateSimpleMapping();
        }
      } else if (response.data.status === "failed") {
        console.log("抽出情報の取得完了 - ステータス: failed");
        setExtractionStatus("failed");
      } else if (response.data.status === "processing") {
        console.log("抽出情報の取得完了 - ステータス: processing");
        setExtractionStatus("processing");
        // ポーリングを開始（まだ開始されていない場合）
        if (!statusCheckTimer) {
          startPolling();
        }
      } else {
        console.log("抽出情報の取得完了 - ステータス:", response.data.status);
        // 完了以外のステータスが返された場合は処理中とみなす
        setExtractionStatus("processing");
      }
    } catch (error) {
      console.error("抽出情報の取得に失敗しました:", error);
    }
  };

  // シンプルなマッピングを生成（テキスト内容に基づく簡易的な推測）
  const generateSimpleMapping = () => {
    // 初期化
    const newMapping: ExtractionMapping = {};

    // 通常フィールドとテーブルフィールドを区別して処理
    appFields.forEach((field) => {
      // 新しいスキーマ形式に対応
      if (field.type === "string") {
        // 文字列フィールドの場合
        newMapping[field.name] = [];
      } 
      else if (field.type === "map" && field.fields) {
        // マップ型フィールドの場合
        newMapping[field.name] = {};
        field.fields.forEach(subField => {
          newMapping[field.name][subField.name] = [];
        });
      }
      else if (field.type === "list" && field.items) {
        // リスト型フィールドの場合
        if (field.items.type === "map" && field.items.fields) {
          const listData = extractedInfo[field.name];
          if (Array.isArray(listData) && listData.length > 0) {
            newMapping[field.name] = listData.map(() => {
              const rowMapping: Record<string, number[]> = {};
              field.items!.fields!.forEach(itemField => {
                rowMapping[itemField.name] = [];
              });
              return rowMapping;
            });
          } else {
            newMapping[field.name] = [];
          }
        } else {
          newMapping[field.name] = [];
        }
      } else {
        // 通常フィールドの場合
        const fieldName = field.name;
        const fieldValue = extractedInfo[fieldName];

        if (fieldValue && typeof fieldValue === "string") {
          // OCR結果から該当するテキストを検索
          const matchIndices = findMatchingIndices(fieldValue);
          newMapping[fieldName] = matchIndices;
        } else {
          newMapping[fieldName] = [];
        }
      }
    });

    setMapping(newMapping);
  };

  // テキスト値に一致するOCR結果のインデックスを探す補助関数
  const findMatchingIndices = (value: string) => {
    if (!value || typeof value !== "string" || !ocrWords || !ocrWords.length) {
      return [];
    }

    // 正規化された値
    const normalizedValue = value.replace(/\s+/g, "").toLowerCase();

    // 完全一致か部分一致するテキストのインデックスを探す
    return ocrWords
      .map((result, index) => {
        const normalizedContent = result.content
          .replace(/\s+/g, "")
          .toLowerCase();
        return normalizedContent.includes(normalizedValue) ? index : -1;
      })
      .filter((index) => index !== -1);
  };

  // 情報抽出の開始
  const startExtraction = async () => {
    if (!id) return;

    try {
      setExtractionStatus("processing");
      setPollingAttemptCount(0);

      // 現行構成では旧 /ocr/extract を使わず result を再取得
      setActiveView("extraction");
      await fetchExtractionInfo();

      if (statusCheckTimer) {
        clearInterval(statusCheckTimer);
        statusCheckTimer = null;
      }

      setExtractionStatus("completed");
    } catch (error) {
      console.error("情報抽出の開始に失敗しました:", error);
      setExtractionStatus("failed");
    }
  };

  // 抽出ステータスのポーリング
  const startPolling = () => {
    if (statusCheckTimer) {
      clearInterval(statusCheckTimer);
    }

    statusCheckTimer = setInterval(async () => {
      setPollingAttemptCount((prev) => prev + 1);

      try {
        // 情報抽出のステータスを確認
        await checkExtractionStatus();

        // タイムアウト処理
        if (
          pollingAttemptCount >= MAX_POLLING_ATTEMPTS &&
          extractionStatus === "processing"
        ) {
          console.warn("抽出処理に時間がかかっています。処理は継続中です。");
          if (statusCheckTimer) {
            clearInterval(statusCheckTimer);
            statusCheckTimer = null;
          }
        }
      } catch (error) {
        console.error("ステータスチェック中にエラーが発生しました:", error);
        // エラーが発生しても即座に失敗にはせず、タイムアウトまで継続
        if (pollingAttemptCount >= MAX_POLLING_ATTEMPTS) {
          setExtractionStatus("failed");
          if (statusCheckTimer) {
            clearInterval(statusCheckTimer);
            statusCheckTimer = null;
          }
        }
      }
    }, POLLING_INTERVAL);
  };

  // OCR結果の保存
  const saveOcrEdit = async (words = ocrWords) => {
    if (!id) return;

    try {
      const response = await api.post(`/ocr/edit/${id}`, {
        words: words,
      });

      if (response.data.status === "success") {
        console.log("OCR結果が保存されました");
        showToast("OCR結果が保存されました", "success");
      }
    } catch (error) {
      console.error("OCR結果の保存に失敗しました:", error);
      showToast("OCR結果の保存に失敗しました", "error");
    }
  };

  // 抽出情報の保存
  const saveExtractedInfo = async (dataToSave?: Record<string, any>) => {
    if (!id) return;

    try {
      const infoToSave = dataToSave || extractedInfo;
      // 最新の状態を使用してPOSTリクエストを送信
      console.log("保存するデータ:", infoToSave);

      console.warn("custom prompt save skipped: old /ocr/extract/edit API is disabled");
      return;
    } catch (error) {
      console.error("抽出情報の保存に失敗しました:", error);
      showToast("抽出情報の保存に失敗しました", "error");
    }
  };

  // 通知を表示する関数
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({
      show: true,
      message,
      type
    });
  };
  
  // トースト通知を閉じる
  const closeToast = () => {
    setToast(prev => ({ ...prev, show: false }));
  };

  // エージェント実行
  const runAgent = async (): Promise<Suggestion[]> => {
    if (!id) return [];

    try {
      setAgentStatus('running');
      console.log("エージェント実行中...");
      
      const response = await apiRunAgent(id);
      
      setAgentStatus('completed');
      console.log("エージェント実行完了:", response);
      
      if (response.suggestions.length > 0) {
        showToast(`${response.suggestions.length}件の修正提案があります`, 'info');
      } else {
        showToast('問題は検出されませんでした', 'success');
      }
      
      return response.suggestions;
    } catch (error) {
      console.error("エージェント実行エラー:", error);
      setAgentStatus('idle');
      showToast('エージェント実行に失敗しました', 'error');
      return [];
    }
  };

  // ツール一覧取得
  const getTools = async (): Promise<Tool[]> => {
    try {
      return [];
    } catch (error) {
      console.error("ツール取得エラー:", error);
      showToast('ツール情報の取得に失敗しました', 'error');
      return [];
    }
  };
  
  // 抽出ステータスの確認
  const checkExtractionStatus = async () => {
    if (!id) return;

    try {
      console.log("抽出ステータスを確認中...");
      await fetchExtractionInfo();
      const status = extractionStatus;
      console.log("抽出ステータス:", status);

      if (status === "completed") {
        setExtractionStatus("completed");
        // 抽出情報を再取得
        await fetchExtractionInfo();
        // ポーリングを停止
        if (statusCheckTimer) {
          clearInterval(statusCheckTimer);
          statusCheckTimer = null;
        }
      } else if (status === "failed") {
        setExtractionStatus("failed");
        // ポーリングを停止
        if (statusCheckTimer) {
          clearInterval(statusCheckTimer);
          statusCheckTimer = null;
        }
      } else {
        setExtractionStatus("processing");
      }
    } catch (error) {
      console.error("抽出ステータスの確認に失敗しました:", error);
      throw error;
    }
  };

  // 特定のフィールドに関連するテキストとバウンディングボックスをハイライト
  const highlightField = (fieldPath: string, stayOnExtractionView = true) => {
    console.log("highlightField呼び出し:", fieldPath, stayOnExtractionView);
    
    // 新しいページ対応ハイライト機能を使用
    handleExtractedFieldClick(fieldPath);
    
    // 明示的に画面遷移が要求された場合のみ切り替える
    if (stayOnExtractionView === false) {
      setActiveView("ocr");
    }
  };

  // テーブルセルのハイライト処理（ページ指定版）
  const highlightTableCellOnPage = (cellIndices: number[], targetPage: number) => {
    const firstGlobalIndex = cellIndices[0];
    const targetWord = ocrWords[firstGlobalIndex];
    
    if (!targetWord) {
      return;
    }
    
    // 現在のページでの相対インデックスに変換
    const currentPageWords = isMultipage 
      ? ocrWords.filter(word => (word.page === targetPage || (!word.page && targetPage === 1)))
      : ocrWords;
      
    const relativeIndex = currentPageWords.findIndex(pageWord => 
      pageWord.content === targetWord.content && 
      JSON.stringify(pageWord.points) === JSON.stringify(targetWord.points)
    );
    
    if (relativeIndex !== -1) {
      setSelectedIndex(relativeIndex);
    }
  };

  // テーブルセルの関連テキストをハイライト
  const highlightTableCell = (
    fieldName: string,
    rowIndex: number,
    columnName: string
  ) => {
    const fieldMapping = mapping[fieldName];
    
    // 新しいスキーマ形式（list型）の場合
    if (Array.isArray(fieldMapping) && fieldMapping[rowIndex]) {
      const rowMapping = fieldMapping[rowIndex];
      if (typeof rowMapping === 'object' && rowMapping !== null && !Array.isArray(rowMapping)) {
        const cellIndices = rowMapping[columnName];
        
        if (Array.isArray(cellIndices) && cellIndices.length > 0) {
          // グローバルインデックスを相対インデックスに変換
          const firstGlobalIndex = cellIndices[0];
          const targetWord = ocrWords[firstGlobalIndex];
          
          if (targetWord) {
            const targetPage = targetWord.page || 1;
            const targetPageIndex = targetPage - 1;
            
            // 現在のページと異なる場合はページ切り替え
            if (targetPageIndex !== currentPageIndex) {
              setCurrentPageIndex(targetPageIndex);
              setImageSrc(imageUrls[targetPageIndex]?.url || "");
              
              // ページ切り替え後にハイライト処理を実行
              setTimeout(() => {
                highlightTableCellOnPage(cellIndices, targetPage);
              }, 100); // 画像読み込み待ち
            } else {
              // 同じページの場合は即座にハイライト
              highlightTableCellOnPage(cellIndices, targetPage);
            }
          }
          
          // 画面遷移しない
          return;
        }
      }
    }
    
    // 旧形式（table型）の場合も同様に処理
    if (Array.isArray(fieldMapping) && fieldMapping[rowIndex]) {
      const rowMapping = fieldMapping[rowIndex];
      if (typeof rowMapping === 'object' && rowMapping !== null && !Array.isArray(rowMapping)) {
        const cellIndices = rowMapping[columnName];
        
        if (Array.isArray(cellIndices) && cellIndices.length > 0) {
          // グローバルインデックスを相対インデックスに変換
          const firstGlobalIndex = cellIndices[0];
          const targetWord = ocrWords[firstGlobalIndex];
          
          if (targetWord) {
            const targetPage = targetWord.page || 1;
            const targetPageIndex = targetPage - 1;
            
            // 現在のページと異なる場合はページ切り替え
            if (targetPageIndex !== currentPageIndex) {
              setCurrentPageIndex(targetPageIndex);
              setImageSrc(imageUrls[targetPageIndex]?.url || "");
              
              // ページ切り替え後にハイライト処理を実行
              setTimeout(() => {
                highlightTableCellOnPage(cellIndices, targetPage);
              }, 100); // 画像読み込み待ち
            } else {
              // 同じページの場合は即座にハイライト
              highlightTableCellOnPage(cellIndices, targetPage);
            }
          }
          
          // 画面遷移しない
          return;
        }
      }
    }
  };

  // 抽出情報の更新通知用関数
  const updateExtractedInfo = (newInfo: Record<string, any>) => {
    setExtractedInfo(newInfo);
  };

  // OCR結果の更新
  const updateOcrResults = (updatedWords: OcrWord[]) => {
    setOcrWords(updatedWords);
    // 自動的に保存処理を実行
    saveOcrEdit(updatedWords);
  };

  // テキストボックスをクリックしたときのハンドラ
  const handleTextBoxClick = (index: number) => {
    setSelectedIndex(index);
  };

  // コンポーネントのマウント時にOCR結果を取得
  useEffect(() => {
    console.log("OCRResult コンポーネントがマウントされました");
    fetchOcrResult();

    // コンポーネントのアンマウント時にクリーンアップ
    return () => {
      console.log("OCRResult コンポーネントがアンマウントされます");
      // ステータスチェックタイマーのクリア
      if (statusCheckTimer) {
        clearInterval(statusCheckTimer);
        statusCheckTimer = null;
      }

      // オブジェクトURLを解放
      if (imageSrc && imageSrc.startsWith("blob:")) {
        URL.revokeObjectURL(imageSrc);
      }
    };
  }, [fetchOcrResult]);

  // 再度抽出ハンドラー
  const handleReExtract = () => {
    setShowConfirmModal(true);
  };

  const handleVerificationChange = async (completed: boolean) => {
    if (!id) return;
    
    setVerificationCompleted(completed); // 楽観的UI更新
    try {
      showToast(completed ? '確認完了にしました' : '確認完了を解除しました', 'success');
    } catch (error) {
      setVerificationCompleted(!completed); // エラー時はロールバック
      showToast('確認完了の更新に失敗しました', 'error');
    }
  };

  const executeReExtract = async () => {
    if (!id) return;
    
    try {
      setExtractionStatus("processing");
      setPollingAttemptCount(0);
      showToast("情報抽出を開始しました。", "info");
      
      // 現行構成では旧 skip_ocr API は使わず result を再取得
      setActiveView("extraction");
      await fetchExtractionInfo();

      if (statusCheckTimer) {
        clearInterval(statusCheckTimer);
        statusCheckTimer = null;
      }
    } catch (error: any) {
      console.error("再抽出エラー:", error);
      showToast(error.response?.data?.detail?.message || error.response?.data?.detail || "再抽出に失敗しました", "error");
      setExtractionStatus("failed");
    }
  };

  // 表示タイトル
  const currentViewTitle = activeView === "ocr" ? "OCR結果" : "抽出結果";

  // ローディングスピナーコンポーネント
  const LoadingSpinner = () => (
    <div className={styles.loadingContainer}>
      <div className={styles.spinner}></div>
    </div>
  );

  return (
    <div className={styles.container}>
      {/* トーストコンポーネント */}
      <Toast
        show={toast.show}
        message={toast.message}
        type={toast.type}
        onClose={closeToast}
        duration={3000}
      />
      
      {/* 確認モーダル */}
      <ConfirmModal
        isOpen={showConfirmModal}
        onClose={() => setShowConfirmModal(false)}
        onConfirm={executeReExtract}
        title="再度抽出の確認"
        message="OCR処理と情報抽出を最初からやり直します。&#10;現在の抽出結果は上書きされますが、よろしいですか？"
        confirmText="実行"
        cancelText="キャンセル"
      />
      
      <div className={styles.row}>
        {/* 左側：画像プレビューとバウンディングボックス */}
        <div className={styles.leftPanel}>
          <div className={styles.header}>
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate(`/app/${appName}`)}
                disabled={!appName}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded disabled:opacity-50 disabled:cursor-not-allowed"
                title="アップロード画面に戻る"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
              </button>
              <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
              <span className="text-xl font-semibold text-gray-800 truncate max-w-md">
                {filename || "画像プレビュー"}
              </span>
            </div>
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCustomPromptModalOpen(true)}
                  className="px-3 py-1.5 bg-indigo-500 text-white rounded hover:bg-indigo-600 flex items-center gap-1.5 text-sm"
                  title="カスタムプロンプト"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  <span className="hidden sm:inline">カスタムプロンプト</span>
                </button>
                <button
                  onClick={handleReExtract}
                  disabled={loading || extractionStatus === 'processing'}
                  className="px-3 py-1.5 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-1.5 text-sm"
                  title="再度抽出"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  <span className="hidden sm:inline">再度抽出</span>
                </button>
              </div>
            {isMultipage && (
              <div className="flex items-center gap-2">
                <button
                  onClick={goToPreviousPage}
                  disabled={currentPageIndex === 0}
                  className="px-2 py-1 bg-gray-500 text-white rounded disabled:bg-gray-300 disabled:cursor-not-allowed hover:bg-gray-600"
                  title="前のページ"
                >
                  ←
                </button>
                <span className="text-sm text-gray-600">
                  {currentPageIndex + 1} / {totalPages}
                </span>
                <button
                  onClick={goToNextPage}
                  disabled={currentPageIndex === totalPages - 1}
                  className="px-2 py-1 bg-gray-500 text-white rounded disabled:bg-gray-300 disabled:cursor-not-allowed hover:bg-gray-600"
                  title="次のページ"
                >
                  →
                </button>
              </div>
            )}
            </div>
          </div>

          <div className={styles.contentArea}>
            {loading ? (
              <div className={styles.loadingContainer}>
                <LoadingSpinner />
              </div>
            ) : (
              <ImagePreview
                imageSrc={imageSrc}
                boundingBoxes={boundingBoxes}
                selectedIndex={selectedIndex}
                onSelectBox={setSelectedIndex}
                onImageLoad={() => {}}
                onImageError={(error) => {
                  console.error("画像の読み込みに失敗しました:", error);
                }}
              />
            )}
          </div>
        </div>

        {/* 右側：OCR結果と情報抽出 */}
        <div className={styles.rightPanel}>
          <div className={styles.header}>
            <h2 className={styles.title}>{currentViewTitle}</h2>
          </div>

          {loading ? (
            <div className={styles.loadingContainer}>
              <LoadingSpinner />
            </div>
          ) : activeView === "ocr" ? (
            /* OCR結果表示 */
            <div className={styles.contentArea}>
              {isOcrEnabled() ? (
                ocrWords.length > 0 ? (
                  <>
                    <div className="mb-4 p-2">
                      <button
                        onClick={() => changeView("extraction")}
                        className="px-4 py-2 rounded bg-gray-500 hover:bg-gray-600 text-white"
                      >
                        抽出画面へ戻る
                      </button>
                    </div>
                    <OcrResultEditor
                      ocrResults={ocrWords}
                      selectedIndex={selectedIndex}
                      onUpdateOcrResults={updateOcrResults}
                      onStartExtraction={startExtraction}
                      onSelectIndex={handleTextBoxClick}
                    />
                  </>
                ) : (
                  <div className="flex justify-center items-center flex-grow text-gray-500">
                    <div className="text-center">
                      <p className="text-lg mb-2">OCR情報がありません</p>
                      <p className="text-sm">この画像はOCR処理されていないか、OCR結果が見つかりませんでした。</p>
                    </div>
                  </div>
                )
              ) : (
                <div className="flex justify-center items-center flex-grow text-gray-500">
                  <div className="text-center">
                    <p className="text-lg mb-2">OCRモードが無効です</p>
                    <p className="text-sm">このデプロイメントではOCR機能が無効になっています。</p>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* 情報抽出結果表示 */
            <div className={styles.scrollContainer}>
              {/* 抽出ステータス表示 */}
              {extractionStatus !== "completed" ? (
                <ExtractionStatusDisplay
                  status={extractionStatus}
                  pollingAttemptCount={pollingAttemptCount}
                  onRetry={startExtraction}
                  onStartExtraction={startExtraction}
                />
              ) : (
                /* 抽出結果の表示 */
                <ExtractedInfoDisplay
                  extractedInfo={extractedInfo}
                  fields={appFields}
                  onSave={saveExtractedInfo}
                  onHighlightField={highlightField}
                  onHighlightCell={highlightTableCell}
                  onUpdateExtractedInfo={updateExtractedInfo}
                  onRunAgent={runAgent}
                  agentStatus={agentStatus}
                  onGetTools={getTools}
                  activeView={activeView}
                  onBackToExtraction={() => changeView("extraction")}
                  onViewOcr={() => changeView("ocr")}
                  isOcrEnabled={isOcrEnabled()}
                  verificationCompleted={verificationCompleted}
                  onVerificationChange={handleVerificationChange}
                />
              )}
            </div>
          )}
        </div>
      </div>

      {/* カスタムプロンプトモーダル */}
      <CustomPromptModal
        isOpen={customPromptModalOpen}
        onClose={() => setCustomPromptModalOpen(false)}
        appName={appName}
      />
    </div>
  );
}

export default OcrResult;
